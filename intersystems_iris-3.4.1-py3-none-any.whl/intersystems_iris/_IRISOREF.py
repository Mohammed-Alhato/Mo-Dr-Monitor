class _IRISOREF(object):

    def __init__(self, oref):
        self._oref = oref
