from decimal import Decimal
import datetime
import pytest
import intersystems_iris.dbapi._DBAPI as dbapi
from intersystems_iris.dbapi.preparser._PreParser import StatementType


@pytest.fixture(scope="class")
def connection(request):
    if request.config.getoption("--embedded"):
        config = {"embedded": True}
    else:
        config = {
            "hostname": request.config.getoption("--iris-host"),
            "port": request.config.getoption("--iris-port", 1972),
            "namespace": request.config.getoption("--iris-namespace"),
            "username": request.config.getoption("--iris-username"),
            "password": request.config.getoption("--iris-password"),
        }
    with dbapi.connect(**config) as conn:
        if "embedded" in config:
            conn.iris.system.SQL.Purge()
        yield conn


class TestMain:
    cleanup = []

    @pytest.fixture
    def cursor(self, connection):
        with connection.cursor() as cursor:
            yield cursor

    def create(self, cursor, type, name, body):
        cursor.execute(f"CREATE {type} {name} {body}")
        yield name
        cursor.execute(f"DROP {type} {name}")

    @pytest.fixture
    def proc_test(self, cursor):
        yield from self.create(
            cursor,
            "PROCEDURE",
            "test",
            """(val VARCHAR(10), fail BIT)
RETURNS VARCHAR(10)
LANGUAGE PYTHON
{
    if fail:
        raise Exception('error')
    return ":" + val
}
""",
        )

    @pytest.fixture
    def table_test(self, cursor):
        yield from self.create(
            cursor,
            "TABLE",
            "test",
            "(id IDENTITY PRIMARY KEY, val VARCHAR('')) WITH %CLASSPARAMETER ALLOWIDENTITYINSERT = 1",
        )

    @pytest.fixture
    def table_test_streams(self, cursor):
        yield from self.create(
            cursor,
            "TABLE",
            "test",
            "(charstream LONGVARCHAR, binarystream LONGVARBINARY)",
        )

    @classmethod
    def teardown_class(self):
        pass

    def test_simple(self, cursor: dbapi.Cursor):
        _ = cursor.execute("select ?", [1])
        rows = cursor.fetchall()
        assert rows == [[1]]

    def test_literals(self, cursor: dbapi.Cursor):
        some_date = datetime.date(2012, 2, 3)
        some_datetime = datetime.datetime(2012, 2, 3, 10, 11, 12, 123)
        some_time = datetime.time(10, 11, 12, 123)
        some_decimal = Decimal("1.234")

        params = [
            2,
            some_date,
            some_datetime,
            some_time,
            some_decimal,
            None,
            "",
            True,
            False,
        ]
        _ = cursor.execute("select 'text', 1, " + ", ".join(["?"] * len(params)), params)
        rows = cursor.fetchall()
        assert rows == [
            [
                "text",
                1,
                2,
                "2012-02-03",
                "2012-02-03 10:11:12.000123",
                "10:11:12.000123",
                Decimal("1.234"),
                None,
                "",
                1,
                0,
            ]
        ]

    def test_with(self, cursor):
        cursor.execute("with t1 as (select 1), t2 as (select 2) select * from t1 union all select * from t2")
        rows = cursor.fetchall()
        assert rows == [[1], [2]]

    def test_lateral(self, cursor):
        cursor.execute("select * from (select ?) t1,  (select ?) t2", [1, 2])
        rows = cursor.fetchall()
        assert rows == [[1, 2]]

    def test_select_proc(self, cursor, proc_test):  # noqa

        cursor.execute("select test('test1', 0)")
        row = cursor.fetchone()
        assert row == [":test1"]

        with pytest.raises(dbapi.InterfaceError):
            cursor.execute("select test('test1', 1)")

        cursor.execute("select test('test2', 0)")
        row = cursor.fetchone()
        assert row == [":test2"]

        with pytest.raises(dbapi.InterfaceError):
            cursor.execute("select test(?, ?)", ["test1", 1])

    def test_call(self, cursor, proc_test):  # noqa

        cursor.execute("CALL test('test1', 0)")
        with pytest.raises(dbapi.InterfaceError):
            cursor.execute("CALL test('test2', 1)")

        cursor.execute("CALL test(?, ?)", ["test1", False])
        with pytest.raises(dbapi.InterfaceError):
            cursor.execute("CALL test(?, ?)", ["test2", True])

    def test_insert(self, cursor, table_test):
        cursor.execute("INSERT INTO test (id) VALUES (2)")
        assert cursor.rowcount == 1
        assert cursor.lastrowid == 2

        cursor.execute("INSERT INTO test (id) DEFAULT VALUES")
        assert cursor.rowcount == 1
        assert cursor.lastrowid == 3

        cursor.executemany("INSERT INTO test (id) VALUES (?)", [(5,), (7,), (9,)])
        assert cursor.rowcount == 3
        assert cursor.lastrowid == 9

        cursor.execute("INSERT INTO test (id, val) VALUES (10, 1), (11, 2), (12, 3)")
        assert cursor.rowcount == 3
        assert cursor.lastrowid == 12

        cursor.execute("INSERT INTO test (id) VALUES (?), (?), (?)", [15, 16, 17])
        assert cursor.rowcount == 3
        assert cursor.lastrowid == 17

        cursor.execute("SELECT id FROM test")
        rows = cursor.fetchall()
        values = [v for row in rows for v in row]
        assert values == [2, 3, 5, 7, 9, 10, 11, 12, 15, 16, 17]

    def test_streams(self, cursor, table_test_streams):
        data = [
            ['plain text', None],
            (None, b'binary data'),
            ['Caché', bytes('Caché', 'utf-8')]
        ]
        cursor.executemany('INSERT INTO test (charstream, binarystream) VALUES (?, ?)', data)

        cursor.execute("SELECT charstream, binarystream FROM test")
        rows = cursor.fetchall()
        data = [list(row) for row in data]
        assert rows == data

    def test_cursor_iter(self, cursor):
        cursor.execute("SELECT 1 UNION ALL SELECT 2")
        rows = []
        for row in cursor:
            rows.append(row[0])

        assert rows == [1, 2]
